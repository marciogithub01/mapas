import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function AddLocationScreen({ navigation, route, addLocation }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');

  useEffect(() => {
    if (route.params?.latitude && route.params?.longitude) {
      setLatitude(route.params.latitude.toString());
      setLongitude(route.params.longitude.toString());
    }
  }, [route.params]);

  const handleAdd = () => {
    const lat = parseFloat(latitude);
    const lon = parseFloat(longitude);

    if (!name || !description || isNaN(lat) || isNaN(lon)) {
      Alert.alert('Erro', 'Preencha todos os campos corretamente.');
      return;
    }

    addLocation({ name, description, latitude: lat, longitude: lon });
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Text>Nome:</Text>
      <TextInput style={styles.input} value={name} onChangeText={setName} />
      <Text>Descrição:</Text>
      <TextInput style={styles.input} value={description} onChangeText={setDescription} />
      <Text>Latitude:</Text>
      <TextInput
        style={styles.input}
        value={latitude}
        onChangeText={setLatitude}
        keyboardType="numeric"
      />
      <Text>Longitude:</Text>
      <TextInput
        style={styles.input}
        value={longitude}
        onChangeText={setLongitude}
        keyboardType="numeric"
      />
      <Button title="Adicionar Local" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 8,
    marginBottom: 12,
    borderRadius: 4,
  },
});



