import React from 'react';
import { View, Text, FlatList, StyleSheet } from 'react-native';

export default function ListScreen({ locations }) {
  return (
    <View style={styles.container}>
      <FlatList
        data={locations}
        keyExtractor={(_, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.title}>{item.name}</Text>
            <Text>{item.description}</Text>
          </View>
        )}
        ListEmptyComponent={<Text>Nenhum local cadastrado.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  item: {
    backgroundColor: '#eee',
    padding: 12,
    marginVertical: 6,
    borderRadius: 6,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 16,
  },
});


