import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import MapScreen from './components/screens/MapScreen';
import AddLocationScreen from './components/screens/AddLocationScreen';
import ListaScreen from './components/screens/ListaScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  const [locations, setLocations] = useState([]);

  const addLocation = (location) => {
    setLocations((prev) => [...prev, location]);
  };

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Map">
        <Stack.Screen name="Map">
          {(props) => <MapScreen {...props} locations={locations} />}
        </Stack.Screen>
        <Stack.Screen name="AddLocation">
          {(props) => <AddLocationScreen {...props} addLocation={addLocation} />}
        </Stack.Screen>
        <Stack.Screen name="List">
          {(props) => <ListaScreen {...props} locations={locations} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}





